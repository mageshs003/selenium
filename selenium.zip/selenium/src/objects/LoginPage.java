package objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	WebDriver driver;
	By SignIn=By.linkText("Sign In");
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
	}
	public WebElement getSignInBtn(WebDriver driver)
	{
		return this.driver.findElement(SignIn);
	}
}