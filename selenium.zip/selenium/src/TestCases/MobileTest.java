package TestCases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MobileTest {
	@BeforeClass
	void beforeClass()
	{
		System.out.println("beforeClass 1");
	}
	@AfterClass
	void afterClass()
	{
		System.out.println("afterClass 1");
	}
	@BeforeMethod
	void beforemethod()
	{
		System.out.println("beforemethod 1");
	}
	@AfterMethod
	void afterMethod()
	{
		System.out.println("afterMethod 1");
	}

	@Test
	void login()
	{
		try {
			System.out.println("Mobile Login");
		int num=10/0;
		}
		catch(Exception ex)
		{
			System.out.println("There is an exception");
		}
	}
 	@Test
 	void logout()
 	{
 		System.out.println("Hello");
 		boolean result=false;
 		SoftAssert soft=new SoftAssert();
 		soft.assertTrue(result);
 		//Assert.assertFalse(result);
 		System.out.println("Bye");
 		soft.assertAll();
 		
 	}
}
