package TestCases;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.*;

public class WebsiteTest {
	@BeforeSuite
	void beforeSuite()
	{
		System.out.println("Before Suite");
	}
	@AfterSuite
	void afterSuit()
	{
		System.out.println("AfterSuite");
	}
	@BeforeTest
	void beforeTest()
	{
		System.out.println("BeforeTest");
	}
	@AfterTest
	void AfterTest()
	{
		System.out.println("AfterTest");
	}
	@BeforeClass
	void beforeClass()
	{
		System.out.println("beforeClass 2");
	}
	@AfterClass
	void afterClass()
	{
		System.out.println("afterClass 2");
	}
	@BeforeMethod
	void beforemethod()
	{
		System.out.println("beforemethod 2");
	}
	@AfterMethod
	void afterMethod()
	{
		System.out.println("afterMethod 2");
	}
	@Parameters({"username"})
	@Test(groups="loginTest")//Enabled=false)
	void login(String u)
	{
		System.out.println("Website Login"+u);
	}
	
	@Test(dataProvider="getData")
	void logout(String username,String password)
	{
	System.out.println("Website Logout"+username""+password);	
	}
	Object[][] getData()
	{
		Object[][]data=new Object[3][2];
		data[0][0]="user1";
		data[0][1]="pass1";
		data[1][0]="user2";
		data[1][1]="pass2";
		data[2][0]="user3";
		data[2][1]="pass3";
		return data;
	}
	

}
