package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SeleniumTest {
	
		WebDriver driver=new ChromeDriver();
		@BeforeMethod
	    void setup() 
		{
			System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
	    }

		@Test
		void test()
		{
			driver.get("https://www.selenium.dev/");
		}
		@AfterMethod
		void tearDown()
		{
			driver.close();
		}
}
