package day2selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LinkValidate {
	public static void main(String[] args) throws MalformedURLException, IOException {
		HttpURLConnection conn=(HttpURLConnection)new URL("https://www.facebook.com/")
				.openConnection();
		conn.setRequestMethod("GET");
		conn.connect();
		System.out.println(conn.getResponseCode());
	}

}
