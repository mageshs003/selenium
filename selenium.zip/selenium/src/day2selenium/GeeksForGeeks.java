package day2selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class GeeksForGeeks {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.geeksforgeeks.org/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.id("userProfileId")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("luser")).sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.id("password")).sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.className("signin-button")).click();
	}
}
