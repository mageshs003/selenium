package day2selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandle {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://the-internet.herokuapp.com/javascript_alerts");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Click for JS Alert']")).click();
		Thread.sleep(3000);
		Alert alertWindow=driver.switchTo().alert();
		System.out.println(alertWindow.getText());
		alertWindow.accept();
		
		driver.findElement(By.xpath("//*[text()='Click for JS Confirm']")).click();
		Thread.sleep(3000);
		Alert confirmWindow=driver.switchTo().alert();
		System.out.println(confirmWindow.getText());
		confirmWindow.dismiss();
		
		driver.findElement(By.xpath("//*[text()='Click for JS Prompt']")).click();
		Thread.sleep(3000);
		Alert promptWindow=driver.switchTo().alert();
		System.out.println(promptWindow.getText());
		promptWindow.sendKeys("magesh");
		promptWindow.accept();
}
}
