package day2selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkValidste2 {
	public static void main(String[] args) throws InterruptedException, MalformedURLException, IOException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement footer=driver.findElement(By.tagName("footer"));
		List<WebElement>links=footer.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(WebElement e:links)
		{
			System.out.println(e.getText()+" ");
			HttpURLConnection conn=(HttpURLConnection)new URL("https://www.facebook.com/")
					.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			System.out.println(conn.getResponseCode());
			if(conn.getResponseCode()==200)
			{
				System.out.println("working");
			}
			else
			{
				System.out.println("Not Working");
			}
			}
		}

}
