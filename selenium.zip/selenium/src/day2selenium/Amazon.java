package day2selenium;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Amazon {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.amazon.in/");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		Actions act=new Actions(driver);
		//WebElement foot=driver.findElement(By.id("nav-link-accountList-nav-line-1"));
		//Actions act=new Actions(driver);
		//act.moveToElement(foot).build().perform();
		WebElement input=driver.findElement(By.id("twotabsearchtextbox"));
		act.keyDown(Keys.SHIFT).build().perform();
		input.sendKeys("hello");
		Thread.sleep(3000);
		act.keyUp(Keys.SHIFT).build().perform();
		input.sendKeys("bye");
		
}
}
