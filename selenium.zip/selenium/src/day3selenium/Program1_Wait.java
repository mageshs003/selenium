package day3selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Program1_Wait {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		//Thread.sleep(3000);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.navigate().to("https://www.geeksforgeeks.org/");
		//Thread.sleep(3000);
		driver.manage().window().maximize();
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				  .withTimeout(Duration.ofSeconds(30))
				  .pollingEvery(Duration.ofSeconds(5))
				  .ignoring(NoSuchElementException.class);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebDriverWait wait1=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(5));
		wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("userProfileId")))).click();
		wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("luser")))).sendKeys("smartmagesh003@gmail.com");
		wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("password")))).sendKeys("magesh@2k02");
		//Thread.sleep(3000);
		//driver.findElement(By.id("userProfileId")).click();
		//Thread.sleep(3000);
		//driver.findElement(By.id("luser")).sendKeys("abc@gmail.com");
		//Thread.sleep(3000);
		//driver.findElement(By.id("password")).sendKeys("abc@gmail.com");
		//Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.className("signin-button")))).click();
		//driver.findElement(By.className("signin-button")).click();
	}
}
