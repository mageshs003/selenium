package day3selenium;

import org.openqa.selenium.chrome.ChromeDriver;

import objects.LoginPage2;

public class PageObjectPracticePageFactory {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.geeksforgeeks.org/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		LoginPage2 obj=new LoginPage2(driver);
		obj.getSignInBtn(driver).click();		

}

}
