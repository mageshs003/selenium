package day1selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Twitter {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://twitter.com/i/flow/login?lang=en");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement emailBox=driver.findElement(By.id("email"));
		emailBox.sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.id("pass")).sendKeys("12345");
		Thread.sleep(3000);
		driver.findElement(By.name("login")).click();

}
