package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MakeMyTrip {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.makemytrip.com/");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.elementFromPoint(0,0).click()");
		Thread.sleep(3000);
		driver.findElement(By.className("lbl_input")).click();
		Thread.sleep(3000);
		driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("pune");
		Thread.sleep(3000);
		driver.findElements(By.className("calc60")).get(0).click();
		Thread.sleep(3000);
		driver.findElement(By.id("toCity"));
		Thread.sleep(3000);
		driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("chandigarh");
		Thread.sleep(3000);
		driver.findElements(By.className("calc60")).get(0).click();
}
}
