package day1selenium;

public class Program2 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("one");
		Thread.sleep(3000);
		System.out.println("two");
		Thread.sleep(3000);
		System.out.println("Three");
		Thread.sleep(3000);
		System.out.println("four");
		Thread.sleep(3000);
		System.out.println("five");
	}

}
