package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAutomationPractice {
public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	Thread.sleep(3000);
	driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
	Thread.sleep(1000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
	WebElement Name=driver.findElement(By.id("name"));
	Name.sendKeys("Magesh");
	Thread.sleep(3000);
	driver.findElement(By.id("phone")).sendKeys("1234598");
	Thread.sleep(3000);
	driver.findElement(By.id("email")).sendKeys("smartmagesh003@gmail.com");
	Thread.sleep(3000);
	driver.findElement(By.id("password")).sendKeys("jckjs4232");
	Thread.sleep(3000);
	driver.findElement(By.id("address")).sendKeys("chennai tamilnadu");
	Thread.sleep(3000);
	driver.findElement(By.id("male")).click();
	String[] days= {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
	List<WebElement>tags=driver.findElements(By.tagName("input"));
	for(int index=0;index<tags.size();index++)
	{
		if(index==8||index==10||index==12||index==14)
		{
			Thread.sleep(3000);
			tags.get(index).click();
			if(index==14)
				break;
		}
	}
	
}
}
