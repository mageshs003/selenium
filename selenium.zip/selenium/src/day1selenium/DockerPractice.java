package day1selenium;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class DockerPractice {
	public static void main(String[] args) throws MalformedURLException {
		String nodeURL="http://localhost:4444/wd/hub";
		ChromeOptions options=new ChromeOptions();
		RemoteWebDriver driver=new RemoteWebDriver(new URL(nodeURL),options);
		driver.get("https://hub.docker.com/r/selenium/standalone-chrome");
		System.out.println(driver.getTitle());
	}

}
