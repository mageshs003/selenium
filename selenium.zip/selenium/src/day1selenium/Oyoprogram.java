package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Oyoprogram {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.oyorooms.com/");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement button=driver.findElement(By.className("datePickerDesktop__checkInOutText"));
		button.click();
		Thread.sleep(3000);
		driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		Thread.sleep(3000);
		driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		Thread.sleep(3000);
		driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		Thread.sleep(3000);
		List<WebElement>dates=driver.findElements(By.className("DateRangePicker__DateLabel"));
		for(WebElement d:dates)
		{
			if(d.getText().equals("2")||d.getText().equals("3"))
			{
				Thread.sleep(3000);
				d.click();
				if(d.getText().equals("3"))
					break;
			}
		}
		
	}

}
