package day1selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program6_fblink {
public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	Thread.sleep(3000);
	driver.navigate().to("https://www.facebook.com/");
	Thread.sleep(1000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("windows.scrollBy(0,500)");
	/*WebElement login=driver.findElement(By.name("login"));
	System.out.println(login);
	System.out.println(login.getAttribute("data-testid"));
	System.out.println(login.getCssValue("color"));
	System.out.println(login.getLocation());	
	System.out.println("********************************************************************************************************************************************************************************************************************************");
	System.out.println(login.getTagName());
	System.out.println(login.getText());
	System.out.println(login.getRect().getHeight());*/
	WebElement login=driver.findElement(By.name("login"));
	System.out.println(login.getText());
}
}
