package day1selenium;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {
public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	Thread.sleep(3000);
	driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
	Thread.sleep(1000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
	WebElement country=driver.findElement(By.className("custom-select"));
	Select obj=new Select(country);
	obj.selectByIndex(6);
	Thread.sleep(1000);
	obj.selectByVisibleText("sweden");
	Thread.sleep(1000);
	obj.selectByValue("10");
	
}
}

